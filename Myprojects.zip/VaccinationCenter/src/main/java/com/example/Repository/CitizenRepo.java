package com.example.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Model.CitizenEntity;

public interface CitizenRepo extends JpaRepository<CitizenEntity,Integer> {

		static Optional<CitizenEntity> findByEmailAndPassword(String email,String Password) {
			// TODO Auto-generated method stub
			return null;
		}
}
