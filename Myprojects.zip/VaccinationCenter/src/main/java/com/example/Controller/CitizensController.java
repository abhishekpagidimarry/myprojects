package com.example.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CitizensController {
	@GetMapping(value="/")
	public String gethome() {
		return "Home.jsp";
	}

}
