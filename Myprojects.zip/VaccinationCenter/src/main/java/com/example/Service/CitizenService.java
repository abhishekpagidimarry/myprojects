package com.example.Service;

import org.springframework.stereotype.Service;

import com.example.Model.CitizenEntity;
import com.example.Repository.CitizenRepo;

@Service
public class CitizenService {
	
	public  CitizenRepo citizenRepo;
	
	
	public CitizenService(CitizenRepo citizenRepo) {
		super();
		this.citizenRepo = citizenRepo;
	}


	public CitizenEntity registerUser(String Email,String Password) {
		if(Email != null && Password !=null) {
			CitizenEntity citizenEntity = new CitizenEntity();
			citizenEntity.setEmail(Email);
			citizenEntity.setPassword(Password);
			return CitizenRepo.save(j);
		}
	}
	
}
