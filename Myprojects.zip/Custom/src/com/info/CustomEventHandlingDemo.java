package com.info;
import java.util.EventObject;
import java.util.ArrayList;
import java.util.List;

// Custom event class
class CustomEvent extends EventObject {
    public CustomEvent(Object source) {
        super(source);
    }
}

// Custom event listener interface
interface CustomEventListener {
    void customEventOccurred(CustomEvent event);
}

// Custom event source class
class EventSource {
    private List<CustomEventListener> listeners = new ArrayList<>();

    public void addCustomEventListener(CustomEventListener listener) {
        listeners.add(listener);
    }

    public void removeCustomEventListener(CustomEventListener listener) {
        listeners.remove(listener);
    }

    public void fireEvent() {
        CustomEvent event = new CustomEvent(this);
        for (CustomEventListener listener : listeners) {
            listener.customEventOccurred(event);
        }
    }
}

// Custom event listener implementation
class CustomListener implements CustomEventListener {
    @Override
    public void customEventOccurred(CustomEvent event) {
        System.out.println("Custom event occurred from " + event.getSource());
    }
}

public class CustomEventHandlingDemo {

    public static void main(String[] args) {
        EventSource eventSource = new EventSource();
        CustomListener customListener = new CustomListener();

        // Add custom listener to the event source
        eventSource.addCustomEventListener(customListener);

        // Fire the custom event
        eventSource.fireEvent();
    }
}
