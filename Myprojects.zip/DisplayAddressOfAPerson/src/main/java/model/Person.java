package model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;




@Entity
//defining class name as Table name
@Table
public class Person 
{
//mark id as primary key
@Id
//defining id as column name
@Column
private int id;
//defining name as column name
@Column
private String name;;
//defining Address as column name
@Column
private String Address;
public int getId() 
{
return id;
}
public void setId(int id) 
{
this.id = id;
}
public String getName() 
{
return name;
}
public void setName(String name) 
{
this.name = name;
}
public String getAddress() 
{
return Address;
}
public void setAddress(String Address) 
{
this.Address = Address;
}
}