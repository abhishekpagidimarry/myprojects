package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import model.Person;
import services.PersonService;

public class ProductController {

	//autowired the StudentService class
		@Autowired
		PersonService personService;
		//creating a get mapping that retrieves all the students detail from the database 
		@GetMapping("/person")
		private List<Person> getAllPerson() 
		{
			return personService.getAllPerson();
		}
}
