package com.DI;

public class SpellChecker {
//Constructor
	public SpellChecker() {
		System.out.println("Spell Checker Constructor");
	}
	
//Method
	
	public void checkSpelling() {
		System.out.println("checking is going on");
	}
}
