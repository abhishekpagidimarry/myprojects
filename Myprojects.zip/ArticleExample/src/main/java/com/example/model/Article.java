package com.example.model;

import java.time.LocalDateTime;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;



@Entity

public class Article {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String title;
	private String description;
	private String body;
	private String slug;
	private LocalDateTime createdAt;
	private LocalDateTime updatedAt;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getSlug() {
		return slug;
	}

	public void setSlug(String slug) {
		this.slug = slug;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
//	public void updateSlug() {
//		this.slug = generateSlugFromTitle(this.title);
//	}

	public Article() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Article(Long id, String title, String description, String body, String slug, LocalDateTime createdAt,
			LocalDateTime updatedAt) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.body = body;
		this.slug = slug;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}

//	private String generateSlugFromTitle(String title) {
//		String slug = title.toLowerCase().replaceAll("\\s", "-");
//		slug = org.apache.commons.text.WordUtils.capitalizeFully(slug);
//		slug = slug.replaceAll("[^\\p{ASCII}]", "");
//		return slug;
//	}

	}


