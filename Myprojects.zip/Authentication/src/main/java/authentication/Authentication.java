package authentication;

import java.util.HashMap;
import java.util.Map;

public class Authentication {
    // Simulating a database to store user credentials
    private Map<String, String> users = new HashMap<>();

    // Method for user registration
    public void registerUser(String username, String password) {
        if (!users.containsKey(username)) {
            users.put(username, password);
            System.out.println("User registered successfully!");
        } else {
            System.out.println("Username already exists. Please choose another one.");
        }
    }

    // Method for user login
    public boolean loginUser(String username, String password) {
        String storedPassword = users.get(username);
        if (storedPassword != null && storedPassword.equals(password)) {
            System.out.println("Login successful!");
            return true;
        } else {
            System.out.println("Invalid username or password. Please try again.");
            return false;
        }
    }
}
