package authentication;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
public class AuthenticationTest {

    private Authentication authentication;

    @Before
    public void setUp() {
        authentication = new Authentication();
    }


    @Test
    public void testLoginUser() {
        authentication.registerUser("Abhishek", "Abhi123");
        authentication.registerUser("Satish", "secret");
       

        // Valid login credentials
        assertTrue(authentication.loginUser("Abhishek", "Abhi123"));
       

        // Invalid login credentials
        assertFalse(authentication.loginUser("Satish ", "S123"));
      
    }
}
