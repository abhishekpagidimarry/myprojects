package com.example.demo;

public class Student {
	public String Fname;
	public String Lname;
	public String age;
	
	
	public Student(String fname, String lname, String age) {
		super();
		this.Fname = fname;
		this.Lname = lname;
		this.age = age;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
}
