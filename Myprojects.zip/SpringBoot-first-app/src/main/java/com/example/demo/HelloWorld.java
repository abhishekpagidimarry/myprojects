package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorld {
	
	//http://localhost:8002/hello-world
	@GetMapping("/hello-world")
	public String helloWorld1() {
		return "Hello";
	}

}
