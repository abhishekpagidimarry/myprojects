package Repository;
import org.springframework.data.repository.CrudRepository;

import model.Feedback;

public interface FeedbackRepository extends CrudRepository<Feedback, Long> {
}
