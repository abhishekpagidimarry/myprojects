package com.phase2;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

	public class DBConnection {
		static Connection con;
		public static Connection getConnection() {
			try {
				//Step 1: load driver in memory
				Class.forName("com.mysql.cj.jdbc.Driver");
				//Step 2: Connection with database
				con=DriverManager.getConnection("jdbc:mysql://localhost:3300/StudentDetails","root","Abhinivi@123456");
				}
			catch(Exception e) {
			e.printStackTrace();
			}
			return con;
		}
	}