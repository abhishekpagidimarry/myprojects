package Sample;

public class Hello {
	public static void mail(String[]args) {
		System.out.println("Hello");
	}
}
