package com.RailwayServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
/*		String uname = request.getParameter("name");
		String uemail = request.getParameter("email");
		String upwd = request.getParameter("pass");
		Connection con= null;
		RequestDispatcher dispatcher = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			//Step 2: Connection with database
			con=DriverManager.getConnection("jdbc:mysql://localhost:3300/railway","root","Abhinivi@123456");
			PreparedStatement pst =con.prepareStatement("insert into users(uname,uemail,upwd ) values ?,?,?)");
			pst.setString(1, uname);
			pst.setString(2, uemail);
			pst.setString(3, upwd);
			
			int rowCount = pst.executeUpdate();
			dispatcher = request.getRequestDispatcher("registration.jsp");
			if(rowCount > 0) {
				request.setAttribute("status","success");
			}else {
				request.setAttribute("status", response);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
			con.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}  */
	
		Connection con= null;
		try {
			//Read all values from HTML Page
			String uname =request.getParameter("name");
			String uemail=request.getParameter("name");
			String upwd=request.getParameter("pass");
			
			//Call Connection Method
			con=DriverManager.getConnection("jdbc:mysql://localhost:3300/railway","root","Abhinivi@123456");
			//Create query
			String query="insert into users(uname,uemail,upwd ) values ?,?,?)";
			//Create Statement Object
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setString(1, uemail);
			psmt.setString(2, upwd);
			psmt.setString(3, uname);
			
					
			//execute query
			int ans=psmt.executeUpdate();
			PrintWriter out=response.getWriter();
			if(ans>0)
				out.println("Record Inserted");
			else
				out.println("Record not inserted");
			
		}catch(Exception e) {
			e.printStackTrace();}
				
		
		
		
		
	}

}
