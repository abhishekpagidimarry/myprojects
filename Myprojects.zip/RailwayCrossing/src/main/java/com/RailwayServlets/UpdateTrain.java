package com.RailwayServlets;
import com.RailwayEntities.RailwayDetail;


import railwayJava.RailwayOperations;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateTrain
 */
@WebServlet("/UpdateTrain")
public class UpdateTrain extends HttpServlet {
	private static final long serialVersionUID = 1L;

/**
     * @seeHttpServlet#HttpServlet()
     */
public UpdateTrain() {
super();
// TODO Auto-generated constructor stub
    }

	/**
	 * @seeHttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String trainId = request.getParameter("trainId");
		String crossing = request.getParameter("crossing");
		String status = request.getParameter("status");
		String name = request.getParameter("name");
		String landmark = request.getParameter("landmark");
		String address = request.getParameter("address");
		String time = request.getParameter("time");
		

		RailwayDetail rwd = new RailwayDetail();
		rwd.setTrainId(Integer.parseInt(trainId));
		rwd.setCrossing(crossing);
		rwd.setStatus(status);
		rwd.setPerson(name);
		rwd.setTime(time);
		rwd.setLandmark(landmark);
		rwd.setAddress(address);
		
		RailwayOperations sos = new RailwayOperations();
		String res = sos.UpdateTraininfo(rwd);
		if(res.equals("Success"))
			response.sendRedirect("ShowAllAdmin.jsp");
	}             
   }
