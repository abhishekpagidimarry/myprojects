package com.RailwayServlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.RailwayEntities.RailwayDetail;

import railwayJava.RailwayOperations;


@WebServlet("/AddTrain")
public class AddTrain extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

		protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			String crossing = request.getParameter("crossing");
			String status = request.getParameter("ddlStatus");
			String name = request.getParameter("name");
			String time = request.getParameter("time");
			String landmark = request.getParameter("landmark");
			String address = request.getParameter("address");
			
			RailwayDetail rwd = new RailwayDetail();
			rwd.setCrossing(crossing);
			rwd.setStatus(status);
			rwd.setPerson(name);
			rwd.setTime(time);
			rwd.setLandmark(landmark);
			rwd.setAddress(address);
			

			RailwayOperations ros = new RailwayOperations();
			String res = ros.AddNewTrain(rwd); 
			
			if(res.equals("Success"))
				response.sendRedirect("NewTrain.jsp");
		
		
		}

	}
