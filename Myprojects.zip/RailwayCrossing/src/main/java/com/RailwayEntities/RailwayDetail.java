package com.RailwayEntities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
	@Table(name="TrainInfo")
	public class RailwayDetail {

		@Id
		@GeneratedValue
		private int trainId;
		private String crossing;
		private String status;
		private String person;
		private String time;
		private String landmark;
		private String address;
		public int getTrainId() {
			return trainId;
		}
		public void setTrainId(int trainId) {
			this.trainId = trainId;
		}
		public String getCrossing() {
			return crossing;
		}
		public void setCrossing(String crossing) {
			this.crossing = crossing;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getPerson() {
			return person;
		}
		public void setPerson(String person) {
			this.person = person;
		}
		public String getTime() {
			return time;
		}
		public void setTime(String time) {
			this.time = time;
		}
		public String getLandmark() {
			return landmark;
		}
		public void setLandmark(String landmark) {
			this.landmark = landmark;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
		
	}







