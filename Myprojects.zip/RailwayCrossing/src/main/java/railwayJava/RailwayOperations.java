package railwayJava;
import java.io.Serializable;
import java.util.List;
import javax.persistence.TypedQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.RailwayEntities.RailwayDetail;
import com.RailwayEntities.UserDetail;




public class RailwayOperations {

	private static final Session HiberConfig = null;
	private Session Factorysfactory = null;
	private SessionFactory sfactory;
	
	public RailwayOperations()
	{
		sfactory = HiberConfig.getSessionFactory();
	}
	
	
	public String AddNewTrain(RailwayDetail trn)
	{
		
		String result = "error";
		
		Session session = sfactory.openSession();
		
		Transaction trans =  session.beginTransaction();
		Serializable s = session.save(trn);
		trans.commit();
		if (s!=null)
			result = "Success";
		return result;
	}
	
	
	public List<RailwayDetail>ShowAll()
	{
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from RailwayDetail");
		List<RailwayDetail>sall = qry.getResultList();
		return sall;
	}
	
	public UserDetail UserCheck(String email, String pwd)
	{
		UserDetail usr = null;
		Session session = sfactory.openSession();
		TypedQuery  qry = session.createQuery("from UserDetail where email=:email and password=:pwd");
		qry.setParameter("email", email);
		qry.setParameter("pwd", pwd);
		List<UserDetail>sall = qry.getResultList();
		if(!sall.isEmpty())
			usr = sall.get(0);
		return usr;
	}

	public String UpdateTraininfo(RailwayDetail rwd)
	{
		String result = "error";
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		
		TypedQuery qry = session.createQuery("Update RailwayDetail set crossing=:crossing, person=:name, time=:time, address=:address, status=:status, landmark=:landmark where trainId=: trainId");
		qry.setParameter("crossing", rwd.getCrossing());
		qry.setParameter("name", rwd.getPerson());
		qry.setParameter("status", rwd.getStatus());
qry.setParameter("time", rwd.getTime());
qry.setParameter("address", rwd.getAddress());
qry.setParameter("landmark", rwd.getLandmark());
qry.setParameter("trainId",rwd.getTrainId());

		int res = qry.executeUpdate();
		trans.commit();
		
		if(res>=1)
			result = "Success";
		
		return result;
	}
	public boolean DeleteTrain(int trainId)
	{
		
		boolean b = false;
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		TypedQuery qry = session.createQuery("Delete from RailwayDetail where trainId=:trainId");
		qry.setParameter("trainId", trainId);
		int res = qry.executeUpdate();
		trans.commit();
		
		if(res>=1)
			b = true;
		
		return b;
	}
	public RailwayDetail GetTrainDetails(int trainId)
	{
		RailwayDetail std = null;
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from RailwayDetail where trainId=:trainId");
		qry.setParameter("trainId", trainId);
		List<RailwayDetail>sall = qry.getResultList();
		
		if(!sall.isEmpty())
			std = sall.get(0);
		
		return std;
	}
	
}

