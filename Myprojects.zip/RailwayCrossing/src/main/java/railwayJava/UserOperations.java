package railwayJava;
import java.io.Serializable;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.RailwayEntities.UserDetail;
public class UserOperations {
	private static final Session HiberConfig = null;
	private SessionFactory  sfactory = null;
	public UserOperations()
	{
		sfactory = HiberConfig.getSessionFactory();
	}
	public String AddNewUser(UserDetail usr)
	{
		String result = "error";
	
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		Serializable s = session.save(usr);
		trans.commit();
		
		if(s!=null)
			result = "Success";
		return result;
	}
	public List<UserDetail>ShowAll()
	{
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from UserDetail");
		List<UserDetail>sall = qry.getResultList();
		return sall;
	}
	public UserDetail UserCheck(String email, String pwd)
	{
		UserDetail usr = null;
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from UserDetail where email=:email and password=:pwd");
		qry.setParameter("email", email);
		qry.setParameter("pwd", pwd);
		List<UserDetail>sall = qry.getResultList();
		if(!sall.isEmpty())
			usr = sall.get(0);
		
		return usr;
	}
	
}
