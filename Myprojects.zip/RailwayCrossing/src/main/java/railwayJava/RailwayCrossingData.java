package railwayJava;

public class RailwayCrossingData {
	private String CrossingStatus;
	private String PersonInCharge;
	private float TrainSchedulu;
	private String Landmark;
	private String Address;
	
}
