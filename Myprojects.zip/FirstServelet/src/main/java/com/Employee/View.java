package com.Employee;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.xdevapi.Statement;

@WebServlet("/View")
public class View extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try {
           
            // Establish a connection to the database
            Connection con = DBConnection.getConnection();

           
            Statement stmt=con.createStatement();

            // Execute the query to retrieve employee records in descending order
            String sqlQuery = "SELECT * FROM Eployees ORDER BY EmpID DESC";
            ResultSet resultSet = con.e

            // Display the employee records
            System.out.println("<html><body>");
            System.out.println("<h2>Employee Records (Descending Order)</h2>");
            System.out.println("<table border=\"1\">");
            System.out.println("<tr><th>Employee ID</th><th>Name</th><th>Department</th></tr>");
            
            while (resultSet.next()) {
                int employeeId = resultSet.getInt("employee_id");
                String name = resultSet.getString("name");
                String department = resultSet.getString("department");
                System.out.println("<tr><td>" + employeeId + "</td><td>" + name + "</td><td>" + department + "</td></tr>");
            }
            
            System.out.println("</table>");
            System.out.println("</body></html>");

            // Clean up resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}






