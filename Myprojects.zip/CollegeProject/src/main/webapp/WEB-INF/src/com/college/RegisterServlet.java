package com.college;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.database.DBHelper;

public class RegisterServlet extends HttpServlet {
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{		
		try{
			response.setContentType("text/html");
			PrintWriter pw=response.getWriter();		
			pw.println(request.getParameter("fullName")+request.getParameter("user"));		
			pw.println("Thanks! For Registering Please Login Now!!");	
	
			String fullName = request.getParameter("fullName");
			String fatherName = request.getParameter("fatherName");
			String motherName = request.getParameter("motherName");
			String emailId = request.getParameter("emailId");
			String phoneNumber = request.getParameter("phoneNum");
			String password = request.getParameter("pswd");
			String user = request.getParameter("user");
			System.out.println(fullName+"  "+fatherName+"   "+motherName+"  "+emailId+"  "+phoneNumber+" "+password+" "+user);
			pw.println("hello");			
			
			if(user.contains("student")){
				DBHelper dbHelper=new DBHelper();
				dbHelper.addUser(fullName,fatherName,motherName,emailId, phoneNumber, password ,user);
			}else{
				DBHelper dbHelper=new DBHelper();
				dbHelper.addTeacher(fullName,fatherName,motherName,emailId, phoneNumber, password ,user);
			}
			
			
			
		}catch (Exception e){
			e.printStackTrace();
		}
		return;
		
	}

}

