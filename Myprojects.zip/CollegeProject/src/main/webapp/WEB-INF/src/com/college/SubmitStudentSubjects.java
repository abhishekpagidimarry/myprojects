package com.college;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.database.DBHelper;
import com.model.Subject;
import com.model.Users;

public class SubmitStudentSubjects extends HttpServlet {
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		try{
		DBHelper helper=new DBHelper();
		HttpSession session=request.getSession();
		Users userInfo=(Users)session.getAttribute("userInfo");
		if(userInfo!=null && userInfo.getUserId()!=null){
			String[] subjectIdList=request.getParameterValues("subject");
			String[] studentIdList=request.getParameterValues("student");
			System.out.println(subjectIdList+" ::: subjectsList ::: studentsList ::: "+studentIdList);
			for(int subjectIndex=0;subjectIndex<subjectIdList.length;subjectIndex++){
				System.out.println("Subject Id "+subjectIdList[subjectIndex]);
				for(int studentIndex=0;studentIndex<studentIdList.length;studentIndex++){
					System.out.println("Student Id "+studentIdList[studentIndex]);
					helper.addStudentSubject(userInfo.getUserId(), studentIdList[studentIndex], subjectIdList[subjectIndex]);
				}
			}			
			
			ArrayList<Subject> subjectList=helper.getSubjects(userInfo.getUserId());
			request.setAttribute("subjectsList", subjectList);
			ArrayList<Users> studentList=helper.getAllStudents();
			request.setAttribute("studentsList", studentList);
		}
		RequestDispatcher rd=request.getRequestDispatcher("jsppages/addstudentsubject.jsp");
		rd.forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
