package com.college;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.database.DBHelper;
import com.model.Subject;
import com.model.Users;

public class ViewStudentSubjects extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		try{
			DBHelper dbHelper=new DBHelper();
			HttpSession session=request.getSession();
			Users userInfo=(Users)session.getAttribute("userInfo");
			if(userInfo!=null && userInfo.getUserId()!=null){
				System.out.println("TeacherId : "+userInfo.getUserId());
				ArrayList<Subject> subjectList=dbHelper.getStudentSubjects(userInfo.getUserId());
				request.setAttribute("subjectList", subjectList);
			}
			
			RequestDispatcher rd=request.getRequestDispatcher("jsppages/viewstudentsubjects.jsp");
			rd.forward(request, response);
		}catch (Exception e){
			e.printStackTrace();
		}
		
	}
}
