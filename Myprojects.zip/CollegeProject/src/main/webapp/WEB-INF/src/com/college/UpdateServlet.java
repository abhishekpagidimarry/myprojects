package com.college;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.database.DBHelper;
import com.model.Profile;
import com.model.Users;

public class UpdateServlet extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String fullname=request.getParameter("fullname");
		String fathername=request.getParameter("fathername");
		String mothername=request.getParameter("mothername");
		String emailid=request.getParameter("emailId");
		String phonenumber=request.getParameter("phoneNum");
		PrintWriter pw=response.getWriter();
		pw.print("hiiiiiii");
		
		HttpSession session=request.getSession();
		Users userInfo=(Users)session.getAttribute("userInfo");
		Long teacher_id=userInfo.getUserId();
	
		if(userInfo!=null && userInfo.getUserId()!=null){
		DBHelper helper=new DBHelper();
		helper.updateUser(teacher_id, fullname, fathername, mothername, emailid, phonenumber);
		Profile profile=helper.getUserProfie(userInfo.getUserId());
		request.setAttribute("profile", profile);
		}
		
		RequestDispatcher rd=request.getRequestDispatcher("jsppages/profile.jsp");
		rd.forward(request, response);
	}
}
