package com.college;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.database.DBHelper;
import com.model.Users;

public class LoginServlet extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		try{
			HttpSession session=request.getSession();
			String emailId = request.getParameter("emailId");	
			String password = request.getParameter("password");	
			String usertype = request.getParameter("usertype");	
			System.out.println(emailId+"    "+password+"     "+usertype);
			DBHelper dbHelper=new DBHelper();
			Users users=dbHelper.getUsersInformation(emailId, password, usertype);
			if(users!=null && users.getUserId()!=null){
				session.setAttribute("userInfo", users);
				RequestDispatcher rd=request.getRequestDispatcher("jsppages/homepage.jsp");
				rd.forward(request, response);
			}else{
				request.setAttribute("failure", "Users details not matched");
				RequestDispatcher rd=request.getRequestDispatcher("jsppages/loginpage.jsp");
				rd.forward(request, response);
			}			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
}
