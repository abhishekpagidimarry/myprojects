package com.college;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.database.DBHelper;
import com.model.Subject;
import com.model.Users;

public class SubjectServlet extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		
		
		String year=request.getParameter("year");
		String semester=request.getParameter("semester");
		String branch=request.getParameter("branch");
		String subjectname=request.getParameter("subname");
		DBHelper helper=new DBHelper();
		
		
		HttpSession session=request.getSession();
		Users userInfo=(Users)session.getAttribute("userInfo");
		System.out.println(year+" "+semester+" "+branch+" "+subjectname);
		if(userInfo!=null && userInfo.getUserId()!=null){
			System.out.println("TeacherId : "+userInfo.getUserId());	
			helper.addSubject(userInfo.getUserId(), year, semester, branch, subjectname);
			ArrayList<Subject> subjectList=helper.getSubjects(userInfo.getUserId());
			request.setAttribute("subjectList", subjectList);
		}
		
		RequestDispatcher rd=request.getRequestDispatcher("jsppages/viewSubjects.jsp");
		rd.forward(request, response);
	}

}
