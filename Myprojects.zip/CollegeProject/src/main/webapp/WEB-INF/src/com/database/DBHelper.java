
package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.model.College;
import com.model.Profile;
import com.model.Subject;
import com.model.Users;

public class DBHelper{
	public static Connection getNonPooledConnection(){
		Connection connection = null;
		try{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/avnproject","root","7600");
		}catch (Exception e){
			e.printStackTrace();
		}
		return connection;
	}
	
	public String addUser(String fullName,String fatherName,String motherName,String emailId,String phoneNumber,String password,String user){
		Connection connection=null;
		PreparedStatement preparedStatement=null; 
		String result="success";
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String createdDate=sdf.format(new Date());
				String query="INSERT INTO student(fullName,fatherName,motherName,emailId,phoneNumber,password,user,created_date,deleteflag) VALUES (?, ?, ?, ?, ?, ?, ? ,?,?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, fullName);
				preparedStatement.setString(2, fatherName);
				preparedStatement.setString(3, motherName);
				preparedStatement.setString(4, emailId);
				preparedStatement.setString(5, phoneNumber);
				preparedStatement.setString(6, password);
				preparedStatement.setString(7, user);
				preparedStatement.setString(8, createdDate);
				preparedStatement.setString(9, "N");
				preparedStatement.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			result=e.getMessage();
	    }finally{
	    	try{
	    		if(preparedStatement!=null){
	    			preparedStatement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		result=e.getMessage();
	    	}
	    }
		return result;
	}
	
	public String addTeacher(String fullName,String fatherName,String motherName,String emailId,String phoneNumber,String password,String user){
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String result="success";
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String createdDate=sdf.format(new Date());
				String query="INSERT INTO teacher(fullName,fatherName,motherName,emailId,phoneNumber,password,user,created_date,deleteflag) VALUES (?, ?, ?, ?, ?, ?, ? ,?,?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, fullName);
				preparedStatement.setString(2, fatherName);
				preparedStatement.setString(3, motherName);
				preparedStatement.setString(4, emailId);
				preparedStatement.setString(5, phoneNumber);
				preparedStatement.setString(6, password);
				preparedStatement.setString(7, user);
				preparedStatement.setString(8, createdDate);
				preparedStatement.setString(9, "N");
				preparedStatement.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			result=e.getMessage();
	    }finally{
	    	try{
	    		if(preparedStatement!=null){
	    			preparedStatement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		result=e.getMessage();
	    	}
	    }
		return result;
	}
	
	
	public Users getUsersInformation(String emailId,String password,String userType){
		Connection connection=null;
		Statement statement=null;
		Users userInfo=null;
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
			String query="";
			if(userType!=null && userType.equalsIgnoreCase("student")){
				query="select * from student where emailid='"+emailId+"' and password='"+password+"'";
			}else if(userType!=null && userType.equalsIgnoreCase("teacher")){
				query="select * from teacher where emailid='"+emailId+"' and password='"+password+"'";
			}
	       	ResultSet resultSet = statement.executeQuery(query);
			if(resultSet!=null){
				userInfo=new Users();
				while(resultSet.next()){
					userInfo.setUserId(resultSet.getLong(1));
					userInfo.setFullName(resultSet.getString(2));
					userInfo.setFatherName(resultSet.getString(3));
					userInfo.setMotherName(resultSet.getString(4));
					userInfo.setEmailId(resultSet.getString(5));
					userInfo.setPhoneNumber(resultSet.getString(6));					
					if(userType!=null && userType.equalsIgnoreCase("student")){
						userInfo.setUserType("Student");
					}else if(userType!=null && userType.equalsIgnoreCase("teacher")){
						userInfo.setUserType("Teacher");
					}
				}
			}
	    }catch (Exception e) {
	    	e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    }
		return userInfo;
	}
	
	
	public String addSubject(Long teacher_id,String year,String semester,String branch,String subjectname){
		Connection connection=null;
		PreparedStatement preparedstatement=null;
		try{
			connection=getNonPooledConnection();
		if(connection!=null){
			String query="INSERT INTO subjects(teacher_id,year,semester,branch,subject_name)VALUES(?,?,?,?,?)";
			preparedstatement=connection.prepareStatement(query);
			preparedstatement.setLong(1, teacher_id);
			preparedstatement.setString(2, year);
			preparedstatement.setString(3, semester);
			preparedstatement.setString(4, branch);
			preparedstatement.setString(5, subjectname);
			preparedstatement.executeUpdate();
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(connection!=null){
					connection.close();
				}if(preparedstatement!=null){
					preparedstatement.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return subjectname;
		
	}
	
	public ArrayList<Subject> getSubjects(Long teacherId){
		Connection connection=null;
		Statement statement=null;
		ArrayList<Subject> subjectList=null;
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
			String query="select * from subjects where teacher_id="+teacherId;
			
	       	ResultSet resultSet = statement.executeQuery(query);
			if(resultSet!=null){
				subjectList = new ArrayList<Subject>();
				while(resultSet.next()){
					Subject subject=new Subject();
					subject.setSubjectId(resultSet.getLong(1));
					subject.setTeacherId(resultSet.getLong(2));
					subject.setYear(resultSet.getString(3));
					subject.setSemester(resultSet.getString(4));
					subject.setBranch(resultSet.getString(5));
					subject.setSubjectName(resultSet.getString(6));
					subjectList.add(subject);
				}
			}
	    }catch (Exception e) {
	    	e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    }
		return subjectList;
	}
	
	public ArrayList<Subject> getStudentSubjects(Long studentId){
		Connection connection=null;
		Statement statement=null;
		ArrayList<Subject> subjectList=null;
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
			String query="select s.subject_name,s.semester,s.year,s.branch,t.fullname,t.emailid from studentsubject ss, teacher t, subjects s where t.teacher_id=ss.teacher_id and s.subject_id=ss.subject_id and ss.student_id="+studentId;
			
	       	ResultSet resultSet = statement.executeQuery(query);
			if(resultSet!=null){
				subjectList = new ArrayList<Subject>();
				while(resultSet.next()){
					Subject subject=new Subject();
					subject.setYear(resultSet.getString(3));
					subject.setSemester(resultSet.getString(2));
					subject.setBranch(resultSet.getString(4));
					subject.setSubjectName(resultSet.getString(1));
					subject.setTeacherFullName(resultSet.getString(5));
					subject.setTeacherEmailId(resultSet.getString(6));
					subjectList.add(subject);
				}
			}
	    }catch (Exception e) {
	    	e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    }
		return subjectList;
	}
	
	
	public Profile getUserProfie(Long teacherId){
		Connection connection=null;
		Statement statement=null;
		Profile profile=null;
		try{
			connection=getNonPooledConnection();
			statement=connection.createStatement();
			String query="select * from teacher where teacher_id="+teacherId;
		ResultSet resultSet=statement.executeQuery(query);
		if(resultSet!=null){
			while(resultSet.next()){
				profile=new Profile();
				profile.setTeacherId(resultSet.getLong(1));
				profile.setFullName(resultSet.getString(2));
				profile.setFatherName(resultSet.getString(3));
				profile.setMotherName(resultSet.getString(4));
				profile.setEmailId(resultSet.getString(5));
				profile.setPhoneNumber(resultSet.getString(6));
				profile.setPassword(resultSet.getString(7));
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
		
		}	return profile;
		
	}
	
	public ArrayList<Users> getAllStudents(){
		Connection connection=null;
		Statement statement=null;		
		ArrayList<Users> studentList=null;		
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
	       	ResultSet resultSet = statement.executeQuery("select * from student");
			if(resultSet!=null){
				studentList=new ArrayList<Users>();				
				while(resultSet.next()){
					Users userInfo=new Users();
					userInfo.setUserId(resultSet.getLong(1));
					userInfo.setFullName(resultSet.getString(2));
					userInfo.setFatherName(resultSet.getString(3));
					userInfo.setMotherName(resultSet.getString(4));
					userInfo.setEmailId(resultSet.getString(5));
					userInfo.setPhoneNumber(resultSet.getString(6));
					studentList.add(userInfo);
				}				
			}
	    }catch (Exception e) {
	    	e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    }
		return studentList;
	}
	
	public String addStudentSubject(Long teacherId, String studentId, String subjectId){
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String result="success";
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String createdDate=sdf.format(new Date());
				String query="INSERT INTO studentsubject(teacher_id,student_id,subject_id) VALUES (?, ?, ?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setLong(1, teacherId);
				preparedStatement.setString(2, studentId);
				preparedStatement.setString(3, subjectId);
				preparedStatement.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			result=e.getMessage();
	    }finally{
	    	try{
	    		if(preparedStatement!=null){
	    			preparedStatement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		result=e.getMessage();
	    	}
	    }
		return result;
	}
	
	public String updateUser(Long teacher_id,String fullname,String fathername,String mothername,String emailid,String phonenumber){
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String result="success";
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				preparedStatement = connection.prepareStatement("update teacher set fullname=?,fathername=?,mothername=?,emailid=?,phonenumber=? where teacher_id="+teacher_id);
				preparedStatement.setString(1, fullname);
				preparedStatement.setString(2, fathername);
				preparedStatement.setString(3, mothername);
				preparedStatement.setString(4, emailid);
				preparedStatement.setString(5, phonenumber);
				preparedStatement.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			result=e.getMessage();
	    }finally{
	    	try{
	    		if(preparedStatement!=null){
	    			preparedStatement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		result=e.getMessage();
	    	}
	    }
		return result;
	}
	
	public ArrayList<College> getAllTeachers(){
		Connection connection=null;
		Statement statement=null;
		
		ArrayList<College> collegeList=null;
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
	       	ResultSet resultSet = statement.executeQuery("select * from teacher");
			if(resultSet!=null){
				collegeList=new ArrayList<College>();
				while(resultSet.next()){
					College college=new College();
					
					String emailid = college.getEmailId();
					
					college.setFullName(resultSet.getString(2));
					college.setFatherName(resultSet.getString(3));
					college.setMotherName(resultSet.getString(4));
					college.setEmailId(resultSet.getString(5));
					college.setPhoneNumber(resultSet.getString(6));
					college.setPassword(resultSet.getString(7));
					college.setUsertype(resultSet.getString(8));
					
					
					collegeList.add(college);
					
					System.out.println(college.getPassword()+college.getFullName()+college.getFatherName()+college.getMotherName()+college.getEmailId()+college.getPhoneNumber()+college.getUsertype());
				}
				
			}
	    }catch (Exception e) {
	    	e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    }
		return collegeList;
	}	
	
	public ArrayList<Users> viewStudentSubject(String subject_id){
		Connection connection=null;
		Statement statement=null;
		ArrayList<Users> studentsList=null;
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				String query="select s.fullname,s.fathername,s.mothername,s.emailid,s.phonenumber from studentsubject ss,student s where s.student_id=ss.student_id and ss.subject_id="+subject_id;
				statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(query);
				if(resultSet!=null){
					studentsList=new ArrayList<Users>();				
					while(resultSet.next()){
						Users userInfo=new Users();
						userInfo.setFullName(resultSet.getString(1));
						userInfo.setFatherName(resultSet.getString(2));
						userInfo.setMotherName(resultSet.getString(3));
						userInfo.setEmailId(resultSet.getString(4));
						userInfo.setPhoneNumber(resultSet.getString(5));
						studentsList.add(userInfo);
					}				
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    }
		return studentsList;
	}
	}
	/*public String deleteUser(String userId){
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String result="success";
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				preparedStatement = connection.prepareStatement("delete from users where user_id=?");
				preparedStatement.setString(1, userId);	
				preparedStatement.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			result=e.getMessage();
	    }finally{
	    	try{
	    		if(preparedStatement!=null){
	    			preparedStatement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		result=e.getMessage();
	    	}
	    }
		return result;
	}
	
	public String deleteorupdateUser(String userId){
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String result="success";
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				preparedStatement = connection.prepareStatement("update users set deleteflag=? where user_id=?");
				preparedStatement.setString(1, "Y");
				preparedStatement.setString(2, userId);	
				preparedStatement.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			result=e.getMessage();
	    }finally{
	    	try{
	    		if(preparedStatement!=null){
	    			preparedStatement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		result=e.getMessage();
	    	}
	    }
		return result;
	}
	
	public String addUserSim(String userId,String simNumber){
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String result="success";
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String createdDate=sdf.format(new Date());
				String query="INSERT INTO user_sim (user_id,sim_number,activate_flag,create_date) VALUES (?, ?, ?, ?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userId);
				preparedStatement.setString(2, simNumber);
				preparedStatement.setString(3, "Y");
				preparedStatement.setString(4, createdDate);	
				preparedStatement.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			result=e.getMessage();
	    }finally{
	    	try{
	    		if(preparedStatement!=null){
	    			preparedStatement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		result=e.getMessage();
	    	}
	    }
		return result;
	}
	
	public ArrayList<UserSim> getAllUsersSims(){
		Connection connection=null;
		Statement statement=null;
		ArrayList<UserSim> usersList=null;
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
	       	ResultSet resultSet = statement.executeQuery("select * from user_sim");
			if(resultSet!=null){
				usersList=new ArrayList<UserSim>();
				while(resultSet.next()){
					UserSim userSimInfo=new UserSim();
					userSimInfo.setUserId(resultSet.getLong("user_id"));
					userSimInfo.setUserSimId(resultSet.getLong("user_sim_id"));
					userSimInfo.setSimNumber(resultSet.getString("sim_number"));
					userSimInfo.setActivateFlag(resultSet.getString("activate_flag"));
					userSimInfo.setCreatedate(resultSet.getString("create_date"));
					usersList.add(userSimInfo);
				}
			}
	    }catch (Exception e) {
	    	//e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		//e.printStackTrace();
	    	}
	    }
		return usersList;
	}		
	
	public ArrayList<UserSim> getAllUsersInformationAndSimInformation(){
		Connection connection=null;
		Statement statement=null;
		ArrayList<UserSim> usersList=null;
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
	       	ResultSet resultSet = statement.executeQuery("select usr.user_id,usr.first_name,usr.last_name,usr.email_id,usr.address,us.sim_number,us.activate_flag,us.create_date "
	       												+"from users usr, user_sim us where usr.user_id=us.user_id");
			if(resultSet!=null){
				usersList=new ArrayList<UserSim>();
				while(resultSet.next()){
					UserSim userSimInfo=new UserSim();
					userSimInfo.setUserId(resultSet.getLong("user_id"));
					userSimInfo.setFirstName(resultSet.getString("first_name"));
					userSimInfo.setLastName(resultSet.getString("last_name"));
					userSimInfo.setEmailId(resultSet.getString("email_id"));
					userSimInfo.setAddress(resultSet.getString("address"));
					userSimInfo.setSimNumber(resultSet.getString("sim_number"));
					userSimInfo.setActivateFlag(resultSet.getString("activate_flag"));
					userSimInfo.setCreatedate(resultSet.getString("create_date"));
					usersList.add(userSimInfo);
				}
			}
	    }catch (Exception e) {
	    	//e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		//e.printStackTrace();
	    	}
	    }
		return usersList;
	}
	
	public String addUserContacts(String userId,String contactNumber, String contactName){
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String result="success";
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String createdDate=sdf.format(new Date());
				String query="INSERT INTO user_contacts (user_id,contact_number,create_date,contact_name) VALUES (?, ?, ?, ?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userId);
				preparedStatement.setString(2, contactNumber);
				preparedStatement.setString(3, createdDate);
				preparedStatement.setString(4, contactName);	
				preparedStatement.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			result=e.getMessage();
	    }finally{
	    	try{
	    		if(preparedStatement!=null){
	    			preparedStatement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		result=e.getMessage();
	    	}
	    }
		return result;
	}
	
	public ArrayList<UserContacts> getAllUsersContactsInformation(){
		Connection connection=null;
		Statement statement=null;
		ArrayList<UserContacts> userContactsList=null;
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
	       	ResultSet resultSet = statement.executeQuery("select * from user_contacts");
			if(resultSet!=null){
				userContactsList=new ArrayList<UserContacts>();
				while(resultSet.next()){
					UserContacts userContactsInfo=new UserContacts();
					userContactsInfo.setUserContactId(resultSet.getLong("user_contact_id"));
					userContactsInfo.setUserId(resultSet.getLong("user_id"));
					userContactsInfo.setContactNumber(resultSet.getString("contact_number"));
					userContactsInfo.setContactName(resultSet.getString("contact_name"));
					userContactsInfo.setCreateDate(resultSet.getString("create_date"));
					userContactsList.add(userContactsInfo);
				}
			}
	    }catch (Exception e) {
	    	//e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		//e.printStackTrace();
	    	}
	    }
		return userContactsList;
	}
	
	public ArrayList<UserContacts> getAllUsersContactsInformation(String userId){
		Connection connection=null;
		Statement statement=null;
		ArrayList<UserContacts> userContactsList=null;
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
	       	ResultSet resultSet = statement.executeQuery("select * from user_contacts where user_id="+userId);
			if(resultSet!=null){
				userContactsList=new ArrayList<UserContacts>();
				while(resultSet.next()){
					UserContacts userContactsInfo=new UserContacts();
					userContactsInfo.setUserContactId(resultSet.getLong("user_contact_id"));
					userContactsInfo.setUserId(resultSet.getLong("user_id"));
					userContactsInfo.setContactNumber(resultSet.getString("contact_number"));
					userContactsInfo.setContactName(resultSet.getString("contact_name"));
					userContactsInfo.setCreateDate(resultSet.getString("create_date"));
					userContactsList.add(userContactsInfo);
				}
			}
	    }catch (Exception e) {
	    	//e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		//e.printStackTrace();
	    	}
	    }
		return userContactsList;
	}
	
	public ArrayList<UserContacts> getAllUsersInfoContactsInfon(String userId){
		Connection connection=null;
		Statement statement=null;
		ArrayList<UserContacts> userContactsList=null;
		try{
			connection = getNonPooledConnection();
			statement = connection.createStatement();
	       	ResultSet resultSet = statement.executeQuery("select * from users usr, user_contacts uc where usr.user_id=uc.user_id and uc.user_id="+userId);
			if(resultSet!=null){
				userContactsList=new ArrayList<UserContacts>();
				while(resultSet.next()){
					UserContacts userContactsInfo=new UserContacts();
					userContactsInfo.setUserContactId(resultSet.getLong("user_contact_id"));
					userContactsInfo.setUserId(resultSet.getLong("user_id"));
					userContactsInfo.setFirstName(resultSet.getString("first_name"));
					userContactsInfo.setLastName(resultSet.getString("last_name"));
					userContactsInfo.setEmailId(resultSet.getString("email_id"));
					userContactsInfo.setAddress(resultSet.getString("address"));
					userContactsInfo.setContactNumber(resultSet.getString("contact_number"));
					userContactsInfo.setContactName(resultSet.getString("contact_name"));
					userContactsInfo.setCreateDate(resultSet.getString("create_date"));
					userContactsList.add(userContactsInfo);
				}
			}
	    }catch (Exception e) {
	    	//e.printStackTrace();
	    }finally{
	    	try{
	    		if(statement!=null){
	    			statement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		//e.printStackTrace();
	    	}
	    }
		return userContactsList;
	}
	
	public String addUser(User userInfo){
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String result="success";
		try{
			connection = getNonPooledConnection();
			if(connection!=null){
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String createdDate=sdf.format(new Date());
				String query="INSERT INTO users (first_name,last_name,email_id,password,address,create_date,deleteflag) VALUES (?, ?, ?, ?, ?, ?, ?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userInfo.getFirstName());
				preparedStatement.setString(2, userInfo.getLastName());
				preparedStatement.setString(3, userInfo.getEmailId());
				preparedStatement.setString(4, "test");
				preparedStatement.setString(5, userInfo.getAddress());
				preparedStatement.setString(6, createdDate);
				preparedStatement.setString(7, "N");			
				preparedStatement.executeUpdate();
			}
		}catch (Exception e) {
			e.printStackTrace();
			result=e.getMessage();
	    }finally{
	    	try{
	    		if(preparedStatement!=null){
	    			preparedStatement.close();
	    		}
	    		if(connection!=null){
	    			connection.close();
	    		}
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		result=e.getMessage();
	    	}
	    }
		return result;
	}	*/

