package com.college;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.database.DBHelper;
import com.model.Subject;
import com.model.Users;

public class StudentSubjectServlet extends HttpServlet {
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		try{
		DBHelper helper=new DBHelper();
		HttpSession session=request.getSession();
		Users userInfo=(Users)session.getAttribute("userInfo");
		if(userInfo!=null && userInfo.getUserId()!=null){
			ArrayList<Subject> subjectsList=helper.getSubjects(userInfo.getUserId());
			request.setAttribute("subjectsList", subjectsList);
			ArrayList<Users> studentsList=helper.getAllStudents();
			request.setAttribute("studentsList", studentsList);
		}
		RequestDispatcher rd=request.getRequestDispatcher("jsppages/addstudentsubject.jsp");
		rd.forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
