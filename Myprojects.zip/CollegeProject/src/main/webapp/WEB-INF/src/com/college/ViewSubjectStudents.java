package com.college;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.database.DBHelper;
import com.model.Subject;
import com.model.Users;

public class ViewSubjectStudents extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		try{
			HttpSession session=request.getSession();
			Users userInfo=(Users)session.getAttribute("userInfo");
			if(userInfo!=null && userInfo.getUserId()!=null){
				DBHelper helper=new DBHelper();
				ArrayList<Subject>subjectsList=helper.getSubjects(userInfo.getUserId());
				request.setAttribute("subjectsList", subjectsList);				
				
				String[] subjectIdList=request.getParameterValues("subject");
				System.out.println(subjectIdList+" ::: subjectsList ::: studentsList ::: "+subjectIdList);
				ArrayList<Users> studentsList=null;
				for(int subjectIndex=0;subjectIndex<subjectIdList.length;subjectIndex++){
					System.out.println("Subject Id "+subjectIdList[subjectIndex]);
					//request.setAttribute("subjectsId", ""+subjectIdList[subjectIndex]);	
					String subjectIdName=subjectIdList[subjectIndex];
					if(subjectIdName!=null && subjectIdName.indexOf(",")!=-1){
						String tokens[]=subjectIdName.split(",");
						if(tokens!=null && tokens.length==2){
							String subjectId=tokens[0];
							studentsList=helper.viewStudentSubject(subjectId);
							request.setAttribute("subjectsId", ""+subjectId);
							String subjectName=tokens[1];
							request.setAttribute("subjectName", ""+subjectName);
						}
					}
				}
				
				studentsList=helper.getAllStudents();
				request.setAttribute("studentsList", studentsList);
				
				RequestDispatcher rd=request.getRequestDispatcher("jsppages/viewStudent.jsp");
				rd.forward(request, response);
			}			
		}catch(Exception e){
			e.printStackTrace();
		}	
	}
}
