package com.jpa;
import java.util.List;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class ProductService {
        
    @Autowired
    ProductRepository productRepository;//reference object of interface
    
    //get list of all records
    public List<ProductEntity> getAllProduct(){
        return productRepository.findAll();//findAll is a method of jparepository which returns all records in list
    }
        //call findById to get 1 product details
    public ProductEntity getProduct(int id){
        return productRepository.findById(id).get();
    }
        
    public void addProduct(ProductEntity pe){
        productRepository.save(pe);
    }
        
    public void updateProduct(int id, ProductEntity pe){
        if(productRepository.findById(id).isPresent()) {
            ProductEntity oldProductEntity=productRepository.findById(id).get();//fetch record from database
            oldProductEntity.setName(pe.getName());
            oldProductEntity.setDescription(pe.getDescription());
            productRepository.save(oldProductEntity);
        }
    }
        
    public void deleteProduct(int id){
        productRepository.deleteById(id);       
    }
}