package Repository;
import org.springframework.data.repository.CrudRepository;

import com.entity.Feedback;

public interface FeedbackRepository extends CrudRepository<Feedback, Long> {
}
